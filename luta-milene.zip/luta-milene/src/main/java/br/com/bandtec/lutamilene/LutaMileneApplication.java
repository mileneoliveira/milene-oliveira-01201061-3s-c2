package br.com.bandtec.lutamilene;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LutaMileneApplication {

	public static void main(String[] args) {
		SpringApplication.run(LutaMileneApplication.class, args);
	}

}
