package br.com.bandtec.lutamilene;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LutaMileneApplicationTests {

	@Test
	void contextLoads() {
	}

}
